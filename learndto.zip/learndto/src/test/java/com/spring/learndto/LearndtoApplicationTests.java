package com.spring.learndto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearndtoApplicationTests {

	@Test
	void contextLoads() {
	}

}
