package com.spring.learndto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearndtoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearndtoApplication.class, args);
	}

}
